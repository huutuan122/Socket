import socket
import mimetypes
import manageFiles
import time


class Server:
    # co the dung IPv4 address lam SERVER_HOST
    def __init__(self, SERVER_HOST='127.0.0.1', SERVER_PORT=5000):
        self.SERVER_HOST = SERVER_HOST
        self.SERVER_PORT = SERVER_PORT
        self.login = False

    def start(self):
        # TCP server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        server_socket.bind((self.SERVER_HOST, self.SERVER_PORT))

        server_socket.listen(5)

        print("Listening at (%s, %s)" % (self.SERVER_HOST, self.SERVER_PORT))

        while True:

            client_connection, client_address = server_socket.accept()

            print("Connected by", client_address)

            request = client_connection.recv(1024).decode()
            print('Request: ', request)
            if request == "":   # Tranh' cac request rong phat sinh loi
                continue

            self.handle_request(request, client_connection)

            client_connection.close()

        server_socket.close()

    def handle_request(self, request, client_connection):  # Xu li cac request

        # Xem filename va method
        headers = request.split('\n')
        filename = headers[0].split()[1]
        print('Filename: ', filename)
        method_get_post = headers[0].split()[0]
        print('Method:', method_get_post)
        print("\n")

        if method_get_post == 'POST':
            if headers[-1] == 'username=admin&password=admin':
                filename = '/info.html'
                self.login = True

            else:
                filename = '/404.html'
                self.login = True

        if self.login == False and filename != '/':     # De vao homepage
            filename = '/index.html'

        # Khi dung nut logout trong info hoac nut tackmeback trong 404
        if filename == '/logout' or filename == '/back':
            self.login = False
            filename = '/index.html'

        if filename == '/':  # Dieu huong ve home.html
            filename = '/home.html'

        # Doc cac file html tru files.html
        if filename[-4::] == 'html'and filename[1:-5] != 'files':
            try:
                fin = open('html' + filename)

                content = fin.read()
                fin.close()

                content_type = 'text/html'  # Tieu chuan de doc html
                header = 'Content-Type: ' + content_type + '\n'

                response = 'HTTP/1.0 200 OK\n' + header + content

            except FileNotFoundError:
                response = 'HTTP/1.0 404 NOT FOUND\n\nFile Not Found'
            client_connection.send(response.encode())

        elif filename[1:-5] == 'files':  # Doc files.html
            manageFiles.send_files(client_connection)

        else:   # Doc nhi phan cua image
            fin = open(filename[1::], 'rb')
            content = fin.read(1024)

            content_type = 'image/jpg'  # TIeu chuan de doc image
            header = 'Content-Type: ' + content_type + '\n\r\n'
            response = 'HTTP/1.0 200 OK\n' + header
            client_connection.send(response.encode())

            while content:  # Doc lien tuc
                try:
                    client_connection.send(content)
                    content = fin.read(1024)
                except:
                    return None

            fin.close()


if __name__ == '__main__':
    server = Server()
    server.start()
